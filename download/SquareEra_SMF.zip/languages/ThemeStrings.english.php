<?php

$txt['theme_welcome'] = 'Welcome, ';
$txt['theme_messages'] = 'messages,';
$txt['theme_unread'] = ' unread';

?>