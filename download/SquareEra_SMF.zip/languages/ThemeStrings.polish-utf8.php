<?php

$txt['theme_welcome'] = 'Witaj, ';
$txt['theme_messages'] = 'wiadomości,';
$txt['theme_unread'] = ' nieprzeczytanych';

?>